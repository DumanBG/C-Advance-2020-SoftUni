﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

            int num = int.Parse(Console.ReadLine());

            Family family = new Family();
           
            for (int i = 0; i < num; i++)
            {
                string[] dataInput = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string currName = dataInput[0];
                int currAge = int.Parse(dataInput[1]);
                Person currPerson = new Person(currName, currAge);

                family.AddMember(currPerson);

            }

            Person olderMember = family.GetOldestMember();


            Console.WriteLine($"{olderMember.Name} {olderMember.Age}");





        }
    }
}
