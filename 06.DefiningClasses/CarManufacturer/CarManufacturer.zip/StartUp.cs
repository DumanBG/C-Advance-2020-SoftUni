﻿using System;

namespace CarManufacturer
{
    class StartUp
    {
        static void Main()
        {
            Car car = new Car();
            car.Make = "VW";
            car.Model = "Polo";
            car.Year = 2005;

            Console.WriteLine($"Make:{car.Make}\nModel: {car.Model}\nYear:{car.Year}");


        }
    }
}
