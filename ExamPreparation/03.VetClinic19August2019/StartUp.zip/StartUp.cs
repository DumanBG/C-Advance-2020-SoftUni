﻿using System;
using System.Collections.Generic;

namespace VetClinic
{
    public class StartUp
    {
        static void Main()
        {
            Pet pet = new Pet("Pesho", 42, "Vanko");
            List<Pet> pets = new List<Pet>();
            Clinic clinic = new Clinic(3);
                clinic.Add(pet);
            clinic.Add(new Pet("Ivo", 122, "Ivan")); // директно адване 
            clinic.Add(new Pet("Sara", 2, "Kiro"));
            clinic.Add(new Pet("Rex", 12, "Ivo"));
            Console.WriteLine(pet);
            clinic.Remove("Ivo");
            Console.WriteLine();
            Console.WriteLine(clinic.GetStatistics());
            Console.WriteLine(clinic.Count);
            Pet oldestPet = clinic.GetOldestPet();
            Console.WriteLine(oldestPet);

        }
    }
}
