﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VetClinic
{
   public class Clinic
    {
        private List<Pet> data;
        private int capacity;
        

        public Clinic( int capacity)
        {
          
            this.Capacity = capacity;
            data = new List<Pet>();
        }

    //    public List<Pet> Data { get => this.data; set => this.data = value; }
        public int Capacity { get => this.capacity; set =>this.capacity = value; }
        public int Count { get { return data.Count; }  }




        public void Add(Pet pet)
        {
            if (data.Count < Capacity)
            {
                data.Add(pet);
            }
        }

        public bool Remove(string name)
        {
            Pet pet = data.FirstOrDefault(p => p.Name == name);

            if(pet != null)
            {
                return true;
            }
            data.Remove(pet);
            return false;
        }

        public Pet  GetPet(string name, string owner)
        {
            Pet pet = data.FirstOrDefault(p => p.Name == name && p.Owner == owner);
            return pet;

        }
        public Pet GetOldestPet()
        {
            Pet pet = data.OrderByDescending(x => x.Age).FirstOrDefault();
            return pet;
        }

        public string GetStatistics()
        {
            StringBuilder result = new StringBuilder($"The clinic has the following patiens:{Environment.NewLine}");
            foreach (var item in data)
            {
                result.AppendLine($"Pet:{item.Name} with owner {item.Owner}");
            }
            return result.ToString();

        }
    }
}
